<div <?php mediclinic_mikado_class_attribute($holder_classes); ?>>
    <div class="mkdf-process-bg-holder"></div>
    <div class="mkdf-process-inner">
        <?php echo do_shortcode($content); ?>
    </div>
</div>