<?php

include_once MIKADO_CORE_SHORTCODES_PATH.'/icon-box/functions.php';
include_once MIKADO_CORE_SHORTCODES_PATH.'/icon-box/icon-box.php';