<?php
require_once MIKADO_CORE_SHORTCODES_PATH.'/info-list/info-list.php';
require_once MIKADO_CORE_SHORTCODES_PATH.'/info-list/info-list-item.php';
require_once MIKADO_CORE_SHORTCODES_PATH.'/info-list/functions.php';
