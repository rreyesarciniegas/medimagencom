<?php

include_once MIKADO_CORE_SHORTCODES_PATH.'/elliptical-slider/elliptical-slider.php';
include_once MIKADO_CORE_SHORTCODES_PATH.'/elliptical-slider/elliptical-slide.php';
include_once MIKADO_CORE_SHORTCODES_PATH.'/elliptical-slider/functions.php';