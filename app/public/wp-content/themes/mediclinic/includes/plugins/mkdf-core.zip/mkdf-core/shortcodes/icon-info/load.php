<?php

include_once MIKADO_CORE_SHORTCODES_PATH.'/icon-info/functions.php';
include_once MIKADO_CORE_SHORTCODES_PATH.'/icon-info/icon-info.php';