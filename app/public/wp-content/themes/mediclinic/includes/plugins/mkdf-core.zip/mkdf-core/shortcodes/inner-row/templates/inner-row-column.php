<div class="mkdf-irh-column <?php echo esc_attr($column_classes); ?>">
	<?php echo do_shortcode($content); ?>
</div>