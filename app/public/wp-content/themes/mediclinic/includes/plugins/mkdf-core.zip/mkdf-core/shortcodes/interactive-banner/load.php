<?php

include_once MIKADO_CORE_SHORTCODES_PATH.'/interactive-banner/functions.php';
include_once MIKADO_CORE_SHORTCODES_PATH.'/interactive-banner/interactive-banner.php';