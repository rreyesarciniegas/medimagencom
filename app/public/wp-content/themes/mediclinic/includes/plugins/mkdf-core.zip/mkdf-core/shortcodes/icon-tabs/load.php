<?php

include_once MIKADO_CORE_SHORTCODES_PATH.'/icon-tabs/functions.php';
include_once MIKADO_CORE_SHORTCODES_PATH.'/icon-tabs/icon-tabs.php';
include_once MIKADO_CORE_SHORTCODES_PATH.'/icon-tabs/icon-tabs-item.php';