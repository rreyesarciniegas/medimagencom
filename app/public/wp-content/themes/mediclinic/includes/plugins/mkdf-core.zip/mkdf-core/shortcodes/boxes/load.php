<?php

include_once MIKADO_CORE_SHORTCODES_PATH.'/boxes/functions.php';
include_once MIKADO_CORE_SHORTCODES_PATH.'/boxes/boxes.php';
include_once MIKADO_CORE_SHORTCODES_PATH.'/boxes/boxes-item.php';