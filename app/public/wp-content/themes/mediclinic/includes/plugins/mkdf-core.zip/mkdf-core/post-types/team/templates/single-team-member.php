<?php

get_header();

mediclinic_mikado_get_title();

mkdf_core_get_single_team();

get_footer();